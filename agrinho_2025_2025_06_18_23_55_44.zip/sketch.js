let campoLargura = 800;
let campoAltura = 500;
let bola;
let timeVerde = [];
let timeAzul = [];
let numJogadores = 3; // Número de jogadores por time (excluindo o goleiro, que é a bola em si para este exemplo simplificado)

function setup() {
  createCanvas(campoLargura, campoAltura);
  reiniciarJogo();
}

function reiniciarJogo() {
  // Posição inicial da bola
  bola = { x: width / 2, y: height / 2, raio: 15, velocidadeX: 0, velocidadeY: 0 };

  // Criação dos jogadores do time verde
  for (let i = 0; i < numJogadores; i++) {
    timeVerde.push({
      x: random(50, width / 2 - 50),
      y: random(50, height - 50),
      raio: 20,
      cor: color(0, 200, 0), // Verde
      velocidade: 3,
    });
  }

  // Criação dos jogadores do time azul
  for (let i = 0; i < numJogadores; i++) {
    timeAzul.push({
      x: random(width / 2 + 50, width - 50),
      y: random(50, height - 50),
      raio: 20,
      cor: color(0, 0, 200), // Azul
      velocidade: 3,
    });
  }
}

function draw() {
  background(50, 150, 50); // Campo verde escuro

  desenharCampo();
  desenharJogadores();
  desenharBola();
  movimentarJogadores();
  interagirBolaJogadores();
  movimentarBola();
  limitarBolaAoCampo();
  verificarGols();
}

function desenharCampo() {
  // Linhas do campo
  stroke(255);
  strokeWeight(2);
  noFill();

  // Campo principal
  rect(0, 0, campoLargura, campoAltura);

  // Linha do meio campo
  line(width / 2, 0, width / 2, height);

  // Círculo central
  ellipse(width / 2, height / 2, 100);

  // Áreas dos gols (simplificado)
  rect(0, height / 2 - 75, 50, 150); // Área do gol esquerdo
  rect(width - 50, height / 2 - 75, 50, 150); // Área do gol direito

  // Gols (apenas linhas para indicar)
  line(0, height / 2 - 50, 0, height / 2 + 50); // Gol esquerdo
  line(width, height / 2 - 50, width, height / 2 + 50); // Gol direito
}

function desenharJogadores() {
  for (let jogador of timeVerde) {
    fill(jogador.cor);
    ellipse(jogador.x, jogador.y, jogador.raio * 2);
  }
  for (let jogador of timeAzul) {
    fill(jogador.cor);
    ellipse(jogador.x, jogador.y, jogador.raio * 2);
  }
}

function desenharBola() {
  fill(255); // Bola branca
  ellipse(bola.x, bola.y, bola.raio * 2);
}

function movimentarJogadores() {
  // Movimento para o Time Verde (usando WASD)
  if (keyIsDown(87)) { // W
    timeVerde[0].y -= timeVerde[0].velocidade;
  }
  if (keyIsDown(83)) { // S
    timeVerde[0].y += timeVerde[0].velocidade;
  }
  if (keyIsDown(65)) { // A
    timeVerde[0].x -= timeVerde[0].velocidade;
  }
  if (keyIsDown(68)) { // D
    timeVerde[0].x += timeVerde[0].velocidade;
  }
  // Limita os jogadores ao campo
  for (let jogador of timeVerde) {
    jogador.x = constrain(jogador.x, jogador.raio, width / 2 - jogador.raio); // Limita ao lado esquerdo
    jogador.y = constrain(jogador.y, jogador.raio, height - jogador.raio);
  }

  // Movimento para o Time Azul (usando setas do teclado)
  if (keyIsDown(UP_ARROW)) {
    timeAzul[0].y -= timeAzul[0].velocidade;
  }
  if (keyIsDown(DOWN_ARROW)) {
    timeAzul[0].y += timeAzul[0].velocidade;
  }
  if (keyIsDown(LEFT_ARROW)) {
    timeAzul[0].x -= timeAzul[0].velocidade;
  }
  if (keyIsDown(RIGHT_ARROW)) {
    timeAzul[0].x += timeAzul[0].velocidade;
  }
  // Limita os jogadores ao campo
  for (let jogador of timeAzul) {
    jogador.x = constrain(jogador.x, width / 2 + jogador.raio, width - jogador.raio); // Limita ao lado direito
    jogador.y = constrain(jogador.y, jogador.raio, height - jogador.raio);
  }

  // **Observação:** Atualmente, apenas o primeiro jogador de cada time é controlável.
  // Você pode expandir isso para controlar múltiplos jogadores ou adicionar IA.
}

function interagirBolaJogadores() {
  // Interação do time verde com a bola
  for (let jogador of timeVerde) {
    let d = dist(bola.x, bola.y, jogador.x, jogador.y);
    if (d < bola.raio + jogador.raio) {
      // Calcula a direção do "chute"
      let angulo = atan2(bola.y - jogador.y, bola.x - jogador.x);
      bola.velocidadeX = cos(angulo) * 10; // Força do chute
      bola.velocidadeY = sin(angulo) * 10;
    }
  }

  // Interação do time azul com a bola
  for (let jogador of timeAzul) {
    let d = dist(bola.x, bola.y, jogador.x, jogador.y);
    if (d < bola.raio + jogador.raio) {
      // Calcula a direção do "chute"
      let angulo = atan2(bola.y - jogador.y, bola.x - jogador.x);
      bola.velocidadeX = cos(angulo) * 10; // Força do chute
      bola.velocidadeY = sin(angulo) * 10;
    }
  }
}

function movimentarBola() {
  bola.x += bola.velocidadeX;
  bola.y += bola.velocidadeY;

  // Aplica atrito para desacelerar a bola
  bola.velocidadeX *= 0.98;
  bola.velocidadeY *= 0.98;
}

function limitarBolaAoCampo() {
  // Colisão com as paredes superior e inferior
  if (bola.y - bola.raio < 0 || bola.y + bola.raio > height) {
    bola.velocidadeY *= -1;
    bola.y = constrain(bola.y, bola.raio, height - bola.raio);
  }

  // Colisão com as paredes laterais (fora das áreas do gol)
  if (bola.x - bola.raio < 0 && (bola.y < height / 2 - 50 || bola.y > height / 2 + 50)) {
    bola.velocidadeX *= -1;
    bola.x = bola.raio;
  }
  if (bola.x + bola.raio > width && (bola.y < height / 2 - 50 || bola.y > height / 2 + 50)) {
    bola.velocidadeX *= -1;
    bola.x = width - bola.raio;
  }
}

function verificarGols() {
  // Gol do time azul (bola entra no gol esquerdo)
  if (bola.x - bola.raio < 0 && bola.y > height / 2 - 50 && bola.y < height / 2 + 50) {
    console.log("Gol do Time Azul!");
    reiniciarJogo();
  }

  // Gol do time verde (bola entra no gol direito)
  if (bola.x + bola.raio > width && bola.y > height / 2 - 50 && bola.y < height / 2 + 50) {
    console.log("Gol do Time Verde!");
    reiniciarJogo();
  }
}